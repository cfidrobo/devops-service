package com.devops.devops_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevopsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevopsServiceApplication.class, args);
	}

}
