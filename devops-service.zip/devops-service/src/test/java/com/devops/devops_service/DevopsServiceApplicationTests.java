package com.devops.devops_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevopsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
